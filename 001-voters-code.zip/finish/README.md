Symfony Security Voters (free cookies!)
=======================================

Well hi there! This repository holds the code and script
for the KnpUniversity lesson called:

[Symfony Security Voters (free cookies!)](http://knpuniversity.com/screencast/symfony-voters)


